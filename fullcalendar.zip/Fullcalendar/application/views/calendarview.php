<!doctype html>
<html lang="en">

<head>
 <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
   
  <style>
  #maincontainer {
    width:100%;
    height: 100%;
    float:right;
  }

  #leftcolumn {
    float:right;
    display:inline-block;
    width: 120px;
    height: 100%;
   
  }

  #contentwrapper {
    float:right;
    display:inline-block;
    width: -moz-calc(10% - 100px);
    width: -webkit-calc(10% - 100px);
    width: calc(10% - 100px);
    height: 100%;
  }
</style>

</head>



    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
   
            <div class="container-fluid">

                <?php $page_title ?>

  


                <!-- end row -->

                <div class="row justify-content-center mt-5">
                    <div class="col-xl-10 col-md-12 col-sm-12">
                        <div class="card">
                           <div class="card-body">
                                    <div style="display:inline;">     
                          </div>

                                 

                   <div class="container-fluid">
                    <div class="row">
                     <div class="col-md-2">
                   
                   </div>

                     <div class="col-md-1">
                   </div>
                       
                            <div class="col-md-6">
                              <h4 class="card-title text-center">Availability Calendar</h4>
                              <p class="card-title-desc text-center">You Can Manage Your Free Schedule Here </p>
                        </div></div>  
                      <div id="calendar"></div>
                  </div>



                          <div class="modal" tabindex="-1" id="cal_modal">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title"><span id="dis_error" class="text-danger"></span>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                
                                <form id="suspend_form">
                                    <div class="row">
                                      
                                     <div class="col-md-12">
                                        <label >Event</label>
                                          
                                                <select class="form-control" id="event" name="title">
                                                  <option value="">Select event</option>
                                                  
                                                    <option value="Google">Google</option>
                                                     <option value="Youtube">Youtube</option>
                                               
                                                </select>
                                    </div>

                                     <div class="col-md-12">
                                        <label class="mt-2">Date From<span class="text-warning">*</span></label>
                                   <input type="date" class="form-control" id="datefrom" name="start">
                                    </div>

                                      <div class="col-md-12">
                                        <label class="mt-2">Date To<span class="text-warning">*</span></label>
                                   <input type="date" class="form-control" id="dateto" name="end">
                                    </div>
                                </div>
                                 
                                <div class="row">

                                     <div class="col-md-6">
                                        <label class="mt-2">Time From<span class="text-warning">*</span></label>
                                   <input type="time" class="form-control" id="timefrom" name="timestart" >
                                    </div>

                                      <div class="col-md-6">
                                        <label class="mt-2">Time To<span class="text-warning">*</span></label>
                                   <input type="time" class="form-control" id="timeto" name="timeend" >
                                    <span id="time_error" class="text-danger"></span>
                                    </div></div>
                                </form>

                              </div>
                              <div class="modal-footer">
                                <button type="button" id="save_events" class="btn btn-primary">Save</button>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div class="modal" tabindex="-1" id="update_cal_modal">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="btn btn-primary" id="del">Delete</button>
                                <h5 class="modal-title"><span id="up_dis_error" class="text-danger"></span></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                
                                <form id="up_suspend_form">
                                    <div class="row">
                                        <span>Note : <span class="text-warning">*</span> Denoted Field Are Required </span><br><br>
                                     <div class="col-md-12">
                                        <label >Event</label>
                                          <select class="form-control" id="up_titles" name="up_title">
                                                  <option value="">Select event</option>
                                                  
                                                    <option value="Google">Google</option>
                                                     <option value="Youtube">Youtube</option>
                                               
                                                </select>
                                    </div>

                                     <div class="col-md-12">
                                        <label class="mt-2">Date From<span class="text-warning">*</span></label>
                                   <input type="date" class="form-control" id="up_datefrom" name="up_start" readonly>
                                   <input type="hidden" class="form-control" id="up_id" name="up_id" >
                                    </div>

                                      <div class="col-md-12">
                                        <label class="mt-2">Date To<span class="text-warning">*</span></label>
                                   <input type="date" class="form-control" id="up_dateto" name="up_end" readonly>
                                    </div>
                                </div>
                                 
                                <div class="row">

                                     <div class="col-md-6">
                                        <label class="mt-2">Time From<span class="text-warning">*</span></label>
                                   <input type="time" class="form-control" id="up_timefrom" name="up_timestart">
                                    </div>

                                      <div class="col-md-6">
                                        <label class="mt-2">Time To<span class="text-warning">*</span></label>
                                        <input type="time" class="form-control" id="up_timeto" name="up_timeend" >
                                        <span id="up_time_error" class="text-danger"></span>
                                    </div></div>

                                </form>

                              </div>
                              <div class="modal-footer">
                                <button type="button" id="up_save_events" class="btn btn-primary">Save</button>
                              </div>
                            </div>
                          </div>
                        </div>


                  <div class="modal" tabindex="-1" id="day_modal">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title"><span id="dis_error_day" class="text-danger"></span></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                
                                <form id="day_form">
                                    <div class="row">
                                        <span>Note : <span class="text-warning">*</span> Denoted Field Are Required </span><br>
                                     <div class="col-md-12">
                                        <label >Event</label>
                                      <select class="form-control" id="center_name_day">
                                        <option value="">Select event</option>
                                           <option value="Google">Google</option>
                                               <option value="Youtube">Youtube</option>
                                    </select>
                                    </div>

                                    <div class="col-md-12">
                                        <label class="mt-3"> <span>Drag Your Event To Change Date & Time</span></label>
                                     
                                    </div>
                                    <input type="hidden" id="daystart" name="">
                                    <input type="hidden" id="dayend" name="">

                                   
                                </div>


                                </form>

                              </div>
                              <div class="modal-footer">
                                <button type="button" id="save_events_day" class="btn btn-primary">Save</button>
                              </div>
                            </div>
                          </div>
                        </div>


                          
                 
                <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
 
      
    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


     <script>
    



    $(document).ready(function(){
        var calendar = $('#calendar').fullCalendar({
          editable:true,
           firstDay: 1,
            defaultView:'agendaWeek',
            height:650,
             contentHeight:"auto",
             expandRows: true,
            timeFormat: 'H:mm',
           slotLabelFormat:"H:mm",
            header:{
                left:'prev,next today',
                center:'title',
                right:'month,agendaWeek,agendaDay'
            },
            views : {
               agendaWeek : {
                  columnFormat : "ddd D/M"
               }
             },
            
            events:"<?php echo base_url(); ?>Calendar/load",
           selectable:true,
            selectHelper:true,

             // $('#save_events').click(function(){
            select:function(start,end)
            {

                var view=calendar.fullCalendar('getView')

            if(view.name=="month" || view.name=="agendaWeek"){
                   $('#cal_modal').modal('show');

                     var setstart = $.fullCalendar.formatDate(start, "Y-MM-DD");
                      var setend = $.fullCalendar.formatDate(end, "Y-MM-DD");
                       var setfrom = $.fullCalendar.formatDate(start, "HH:mm:ss");
                        var setto = $.fullCalendar.formatDate(end, "HH:mm:ss");

                   
                   $('#datefrom').val(setstart);
                     $('#dateto').val(setend);
                     $('#timefrom').val(setfrom);
                     $('#timeto').val(setto);
               
            }else if( view.name=="agendaDay") 
            {
                 $('#day_modal').modal('show');

                  var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");

               $('#daystart').val(start)
                 $('#dayend').val(end)
           
               
            }
            },
           
            eventResize:function(event)
            {

              if(event.status==1)
              {
                 event.draggable = false;
                 
              }else{

                var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");

                var title = event.title;

                var id = event.id;

                $.ajax({
                    url:"<?php echo base_url(); ?>Calendar/update",
                    type:"POST",
                    data:{title:title, start:start, end:end, id:id},
                    success:function()
                    {
                        calendar.fullCalendar('refetchEvents');
                        Swal.fire({
                            icon: 'success',
                            title: 'Event Updated',
                            showConfirmButton: false,
                            timer: 2500
                             })
                    }
                })
              }
            },
            eventDrop:function(event)
            {

                var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                //alert(start);
                var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                //alert(end);
                var title = event.title;
                var id = event.id;
                $.ajax({
                    url:"<?php echo base_url(); ?>Calendar/update",
                    type:"POST",
                    data:{title:title, start:start, end:end, id:id},
                    success:function(data)
                    {
                        calendar.fullCalendar('refetchEvents');
                            Swal.fire({
                                icon: 'success',
                                title: 'Event Updated',
                                showConfirmButton: false,
                                timer: 2500
                                 })
                       
                    }
                })
            },
            eventClick:function(event)
            {

                var id = event.id;
                $.ajax({
                    "url" : "<?php echo base_url()?>Calendar/get_cal_data",
                    "data" :{
                        id:id
                        },
                    "type" :"POST",
                    dataType: "json",
                     success:function(data)
                     {

                          $('#up_titles').val(data.fw_title);
                          $('#up_datefrom').val(data.fw_start_date);
                          $('#up_dateto').val(data.fw_end_date);
                          $('#up_timefrom').val(data.fw_start_time);
                          $('#up_timeto').val(data.fw_end_time);
                          $('#up_id').val(data.fw_id);

                         $('#update_cal_modal').modal('show');
                         $('#up_time_error').text(null);
                            $('#time_error').text(null);
                     },
                     error:function()
                     {
                       
                     }
                });

            }
        });


          $('#save_events_day').click(function(){
             
                 $('#day_modal').modal('show');
            // var a=prompt('a');


              if($('#center_name_day').val()=="")
               {
                        $('#dis_error_day').text('Note : All Field Required');
                        return false;
                }else{
                          $('#dis_error_day').text(null);
                       $('#day_modal').modal('hide');
                     

               
                   var center=$('#center_name_day').val();
                   var start=$('#daystart').val();
                   var end=$('#dayend').val();


                  $.ajax({
                        url:"<?php echo base_url(); ?>Calendar/insert_day",
                        type:"POST",
                        data:{title:center,start:start,end:end},
                        success:function()
                        {
                            $('#day_form')[0].reset()
                            calendar.fullCalendar('refetchEvents');
                            Swal.fire({
                            icon: 'success',
                            title: 'Event Added Successfully',
                            showConfirmButton: false,
                            timer: 2500
                             })
                        }
                    })
              }
            })




                //save events by month and by week          

             
            $('#save_events').click(function(){
                     

                    if($('#datefrom').val()=="" || $('#dateto').val()=="" || $('#center_name').val()=="" || $('#timeto').val()=="" || $('#timefrom').val()=="")
                    {
                        $('#dis_error').text('Note : All Field Required');
                        return false;
                    }else{
                          $('#dis_error').text(null);
                       $('#cal_modal').modal('hide');

                    $.ajax({
                        url:"<?php echo base_url(); ?>Calendar/insert",
                        type:"POST",
                        data:$('#suspend_form').serialize(),
                        success:function()
                        {
                            $('#suspend_form')[0].reset();
                            calendar.fullCalendar('refetchEvents');
                            Swal.fire({
                            icon: 'success',
                            title: 'Event Added Successfully',
                            showConfirmButton: false,
                            timer: 2500
                             })
                        }
                    })

                   }
                });


                 $('#up_save_events').click(function(){
                     

                    if($('#up_datefrom').val()=="" || $('#up_dateto').val()=="" || $('#up_center_name').val()=="" || $('#up_timeto').val()=="" || $('#up_timefrom').val()=="")
                    {
                        $('#up_dis_error').text('Note : All Field Required');
                        return false;
                    }else{
                          $('#up_dis_error').text(null);
                       $('#update_cal_modal').modal('hide');
                        

                    $.ajax({
                        url:"<?php echo base_url(); ?>Calendar/up_insert",
                        type:"POST",
                        data:$('#up_suspend_form').serialize(),
                        success:function()
                        {
                            $('#up_suspend_form')[0].reset()
                            calendar.fullCalendar('refetchEvents');
                            Swal.fire({
                            icon: 'success',
                            title: 'Event Updated Successfully',
                            showConfirmButton: false,
                            timer: 2500
                             })
                        }
                    })

                   }
                });


                $('#del').click(function(){
                
                        Swal.fire({
                          title: 'Are you sure?',
                          text: "You won't be able to revert this!",
                          icon: 'warning',
                          showCancelButton: true,
                          confirmButtonColor: '#3085d6',
                          cancelButtonColor: '#d33',
                          confirmButtonText: 'Yes, remove it!'
                        }).then((result) => {
                          if (result.value) {
                            var id = $('#up_id').val();
                            $.ajax({
                                url:"<?php echo base_url(); ?>Calendar/delete",
                                type:"POST",
                                data:{id:id},
                                success:function()
                                {
                                    $('#update_cal_modal').modal('hide');
                                    calendar.fullCalendar('refetchEvents');
                                    Swal.fire({
                                    icon: 'success',
                                    title: 'Event Removed',
                                    showConfirmButton: false,
                                    timer: 2500
                                     })
                                }
                            })
                        }
                      });
                });
                



    });


   

    
             
    </script>
</body>

</html>