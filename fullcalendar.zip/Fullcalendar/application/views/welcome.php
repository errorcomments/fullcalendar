<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>


<div class="row justify-content-center mt-5">
<div class="col-md-6">	
<div class="card">

  <div class="card-body">
    <a href="<?php echo base_url('Calendar')?>" class="btn btn-primary">Go To Calendar Page</a><br><br>
    <h2 class="card-title text-center" >Instructions To Use Full Calendar</h2><br>
   
  
<table class="table text-10"  id=table_id>
  <thead  >
    <tr ><h4>1. Check Controller => Calendar<h4></tr>
      <tr ><h4>2. Check View => calendarview<h4></tr>
        <tr ><h4>3. Check Model => Fullcalendar_model<h4></tr>
      <tr><h4>4. Check Database Folder in Project Root Directory And Integrate With Your Project Database</h4> </tr>
  </thead>
  <tbody>
   
  </tbody>
</table>
</div>
</div>
</div></div>
<div class="row justify-content-center mt-5">
<div class="col-md-4">  
</div>
<div class="col-md-6">  
<div class="carda">

  <div class="card-body">
 <img width="140px" src="<?php echo base_url('Files/yt.png')?>" >&nbsp;
 <p>Scan & Subscribe Us</p>
</div></div></div>
</body>
</html>

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>


