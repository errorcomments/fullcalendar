
<?php

class Fullcalendar_model extends CI_Model
{
 function fetch_all_event(){
  $this->db->order_by('fw_id');
  return $this->db->get('calendar_plugin');
 }

 function insert_event($data)
 {
  $this->db->insert('calendar_plugin', $data);
 }

 function update_event($data, $id)
 {
  $this->db->where('fw_id', $id);
  $this->db->update('calendar_plugin', $data);
 }

 function delete_event($id)
 {
  $this->db->where('fw_id', $id);
  $this->db->delete('calendar_plugin');
 }

 function update_insert($data, $id)
 {
  $this->db->where('fw_id', $id);
  $this->db->update('calendar_plugin', $data);
 }

}

?> 